package fr.telecom.compil.type;

public interface VarType
{
	public String getName();

	public int getSize();
}
