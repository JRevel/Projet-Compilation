package fr.telecom.compil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import fr.telecom.compil.type.ArrayType;
import fr.telecom.compil.type.BooleanType;
import fr.telecom.compil.type.IntegerType;
import fr.telecom.compil.type.VarType;

public class SymbolTable
{
	private ArrayList<Scope> scopes = new ArrayList<Scope>();
	
	public SymbolTable(SyntaxicTree AST)
	{
		try {
			Scope scope = new Scope(null);
			scope.loadAST(AST);
		} catch (DuplicateSymbolException e) {
			e.printStackTrace();
		}
	}
	
	public String toString()
	{
		String result = "";
		for(Scope scope : scopes)
		{
			result += "Scope " + scope.getId() + "\n" + scope;
		}
		return result;
	}
	
	public class Symbol
	{
		public String name;
		public VarType type;
		public boolean adr;
		public int disp, depth;
		
		public Symbol(String name, VarType type, boolean adr, int disp, int depth)
		{
			this.name = name;
			this.type = type;
			this.adr = adr;
			this.disp = disp;
			this.depth = depth;
		}
		
		public String toString()
		{
			return name + " " + (adr ? "adr " : "") + type + "(disp : " + disp + ")";
		}
	}
	
	public class FunctionSymbol extends ProcSymbol
	{
		public VarType returnType;

		public FunctionSymbol(String name, VarType returnType, Symbol[] args, int scopeId)
		{
			super(name, args, scopeId);
			this.returnType = returnType;
		}
		
		public String toString()
		{
			String argString = "";
			for(int i=0; i<args.length; i++)
			{
				if(i != 0)
					argString += ", ";
				argString += args[i];
			}
			return returnType + " " + name + "(" + argString + ")" + " : " + scopeId;
		}
	}
	
	public class ProcSymbol
	{
		public String name;
		public Symbol[] args;
		public int scopeId;

		public ProcSymbol(String name, Symbol[] args, int scopeId)
		{
			this.name = name;
			this.args = args;
			this.scopeId = scopeId;
		}
		
		public String toString()
		{
			String argString = "";
			for(int i=0; i<args.length; i++)
			{
				if(i != 0)
					argString += ", ";
				argString += args[i];
			}
			return "void " + name + "(" + argString + ")" + " : " + scopeId;
		}
	}
	
	public class Scope
	{
		private Map<String, Symbol> symbols = new HashMap<String, Symbol>();
		private Map<String, FunctionSymbol> functionSymbols = new HashMap<String, FunctionSymbol>();
		private Map<String, ProcSymbol> procSymbols = new HashMap<String, ProcSymbol>();
		private Scope parent;
		private int id, depth, varsSize;
		
		public int getId() {
			return id;
		}

		public Scope(Scope parent)
		{
			this.id = scopes.size();
			this.parent = parent;
			if(parent != null)
				this.depth = parent.depth+1;
			else this.depth = 0;
			scopes.add(this);
		}
		
		public void loadAST(SyntaxicTree AST) throws DuplicateSymbolException
		{
			SyntaxicTree declarationTree = AST.getChild("DECLARATIONS");
			int disp = 0;
			for(SyntaxicTree tree : declarationTree.getChildren("VAR"))
			{
				VarType type = getTypeFromTree(tree.getChild("TYPE").getChild(0));
				
				for(SyntaxicTree nameTree : tree.getChild("NAME").getChildren())
				{
					Symbol symbol = new Symbol(nameTree.getLabel(), type, false, disp, depth);
					addSymbol(symbol);
					disp += type.getSize();
				}
			}
			varsSize = disp;
			for(SyntaxicTree tree : declarationTree.getChildren("FUNCTION"))
			{
				// R�cup�ration du prototype de la fonction
				SyntaxicTree prototypeTree = tree.getChild("PROTOTYPE");
				VarType returnType = getTypeFromTree(prototypeTree.getChild("TYPE").getChild(0));
				String name = prototypeTree.getChild("NAME").getChild(0).getLabel();
				SyntaxicTree paramsTree = prototypeTree.getChild("PARAMS");
				Symbol params[] = new Symbol[paramsTree.getChildCount()];
				// Ajout du contenu de la fonction dans la liste des scopes
				Scope scope = new Scope(this);
				for(int i=0; i<params.length; i++)
				{
					SyntaxicTree paramTree = paramsTree.getChild(i);
					Symbol symbol = new Symbol(paramTree.getChild("NAME").getChild(0).getLabel(), getTypeFromTree(paramTree.getChild("TYPE").getChild(0)), paramTree.getLabel().equals("ADR"), 0, scope.getDepth());
					params[i] = symbol;
					scope.addSymbol(symbol);
				}
				FunctionSymbol symbol = new FunctionSymbol(name, returnType, params, scope.getId());
				addFunction(symbol);
				scope.loadAST(tree);
				
			}
			for(SyntaxicTree tree : declarationTree.getChildren("PROC"))
			{
				// R�cup�ration du prototype de la fonction
				SyntaxicTree prototypeTree = tree.getChild("PROTOTYPE");
				String name = prototypeTree.getChild("NAME").getChild(0).getLabel();
				SyntaxicTree paramsTree = prototypeTree.getChild("PARAMS");
				Symbol params[] = new Symbol[paramsTree.getChildCount()];
				// Ajout du contenu de la fonction dans la liste des scopes
				Scope scope = new Scope(this);
				for(int i=0; i<params.length; i++)
				{
					SyntaxicTree paramTree = paramsTree.getChild(i);
					Symbol symbol = new Symbol(paramTree.getChild("NAME").getChild(0).getLabel(), getTypeFromTree(paramTree.getChild("TYPE").getChild(0)), paramTree.getLabel().equals("ADR"), 0, scope.getDepth());
					params[i] = symbol;
					scope.addSymbol(symbol);
				}
				ProcSymbol symbol = new ProcSymbol(name, params, scope.getId());
				addProc(symbol);
				scope.loadAST(tree);
			}
		}
		
		public int getDepth()
		{
			return depth;
		}

		public void addSymbol(Symbol symbol) throws DuplicateSymbolException
		{
			if(symbols.containsKey(symbol.name))
				throw new DuplicateSymbolException(symbol.name);
			symbols.put(symbol.name, symbol);
		}
		
		public void addFunction(FunctionSymbol symbol) throws DuplicateSymbolException
		{
			if(functionSymbols.containsKey(symbol.name))
				throw new DuplicateSymbolException(symbol.name);
			functionSymbols.put(symbol.name, symbol);
		}
		
		public void addProc(ProcSymbol symbol) throws DuplicateSymbolException
		{
			if(procSymbols.containsKey(symbol.name))
				throw new DuplicateSymbolException(symbol.name);
			procSymbols.put(symbol.name, symbol);
		}
		
		public VarType getTypeFromTree(SyntaxicTree tree)
		{
			if(tree.getLabel().equals("integer"))
				return new IntegerType();
			else if(tree.getLabel().equals("ARRAY"))
				return new ArrayType(tree);
			else if(tree.getLabel().equals("boolean"))
				return new BooleanType();
			return null;
		}
		
		public Symbol getSymbol(String symbolName) throws SymbolNotFoundException
		{
			if(!symbols.containsKey(symbolName))
			{
				if(parent == null)
					throw new SymbolNotFoundException(symbolName);
				return parent.getSymbol(symbolName);
			}
			return symbols.get(symbolName);
		}
		
		public FunctionSymbol getFunction(String functionName)
		{
			if(!functionSymbols.containsKey(functionName))
			{
				if(parent == null)
					return null;
				return parent.getFunction(functionName);
			}
			return functionSymbols.get(functionName);
		}
		
		public ProcSymbol getProc(String procName)
		{
			if(!procSymbols.containsKey(procName))
			{
				if(parent == null)
					return null;
				return parent.getProc(procName);
			}
			return procSymbols.get(procName);
		}
		
		public String toString()
		{
			String result = "Parent : ";
			if(parent != null)
				result += parent.getId();
			else result += "none";
			result += "\n----------------\nSymbols : \n";
			for(Symbol symbol : symbols.values())
				result += "	" + symbol + "\n";
			result += "Functions : \n";
			for(FunctionSymbol symbol : functionSymbols.values())
				result += "	" + symbol + "\n";
			result += "Procs : \n";
			for(ProcSymbol symbol : procSymbols.values())
				result += "	" + symbol + "\n";
			return result + "----------------\n\n";
		}

		public int getVarsSize()
		{
			return varsSize;
		}
	}
	
	public class DuplicateSymbolException extends Exception
	{
		private String symbolName;
		
		public DuplicateSymbolException(String symbolName)
		{
			this.symbolName = symbolName;
		}
		
		@Override
		public String getMessage()
		{
			return "Variable " + symbolName + " declared twice in the same scope";
		}
	}
	
	public class SymbolNotFoundException extends Exception
	{
		private String symbolName;
		
		public SymbolNotFoundException(String symbolName)
		{
			this.symbolName = symbolName;
		}
		
		@Override
		public String getMessage()
		{
			return "Variable " + symbolName + " not declared in scope";
		}
	}

	public boolean hasSymbol(String varName, int scopeId)
	{
		Scope scope = scopes.get(scopeId);
		return (scope.symbols.containsKey(varName) || (scope.parent != null && hasSymbol(varName, scope.parent.getId())));
	}
	
	public FunctionSymbol getFunction(String functionName, int scopeId) throws SymbolNotFoundException
	{
		FunctionSymbol symbol = scopes.get(scopeId).getFunction(functionName);
		if(symbol == null)
			throw new SymbolNotFoundException(functionName);
		return symbol;
	}
	
	public ProcSymbol getProc(String procName, int scopeId) throws SymbolNotFoundException
	{
		ProcSymbol symbol = scopes.get(scopeId).getProc(procName);
		if(symbol == null)
		{
			symbol = scopes.get(scopeId).getFunction(procName);
			if(symbol == null)
				throw new SymbolNotFoundException(procName);
		}
		return symbol;
	}
	
	public Symbol getSymbol(String name, int scopeId) throws SymbolNotFoundException {

		Scope scope = scopes.get(scopeId);
		return scope.getSymbol(name);
	}
	
}
	
