package fr.telecom.compil.asm;

import java.util.ArrayList;

import fr.telecom.compil.SymbolTable;
import fr.telecom.compil.SyntaxicTree;
import fr.telecom.compil.SymbolTable.Scope;

public interface TreeHandler
{
	public String genBefore(AsmGenerator gen, SyntaxicTree tree, Scope scope); 
	public String genAfter(AsmGenerator gen, SyntaxicTree tree, Scope scope); 
}
