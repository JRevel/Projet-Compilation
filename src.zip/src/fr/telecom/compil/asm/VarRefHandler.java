package fr.telecom.compil.asm;

import fr.telecom.compil.SymbolTable.Scope;
import fr.telecom.compil.SyntaxicTree;

public class VarRefHandler implements TreeHandler{

	public String genBefore(AsmGenerator gen, SyntaxicTree tree, Scope scope) {
		// TODO Auto-generated method stub
		return null;
	}

	public String genAfter(AsmGenerator gen, SyntaxicTree tree, Scope scope) {
		// TODO Auto-generated method stub
		return null;
	}

}
