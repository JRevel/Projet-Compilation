package fr.telecom.compil.asm;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import fr.telecom.compil.SymbolTable;
import fr.telecom.compil.SymbolTable.Scope;
import fr.telecom.compil.SymbolTable.Symbol;
import fr.telecom.compil.SymbolTable.SymbolNotFoundException;
import fr.telecom.compil.SyntaxicTree;

public class AsmGenerator {
	Map<String, TreeHandler> instructionTypes = new HashMap<String, TreeHandler>();
	
	public AsmGenerator()
	{
		instructionTypes.put("WRITE", new WriteHandler());
	}
	
	public TreeHandler getHandler(SyntaxicTree tree)
	{
		return instructionTypes.get(tree.getLabel());
	}
	
	public String genCode(SyntaxicTree tree)
	{
		return "";
	}

	public String genInitCode(int i, int j) {
		String result = "";
		try {
			InputStream ips=new FileInputStream("inits.src");
			InputStreamReader ipsr = new InputStreamReader(ips);
			BufferedReader buffer = new BufferedReader(ipsr);
			String line;
			while((line = buffer.readLine()) != null)
			{
				result += line + "\n";
			}
			buffer.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public String genPrintCode()
	{
		String result = "";
		try {
			InputStream ips=new FileInputStream("print.src");
			InputStreamReader ipsr = new InputStreamReader(ips);
			BufferedReader buffer = new BufferedReader(ipsr);
			String line;
			while((line = buffer.readLine()) != null)
			{
				result += line + "\n";
			}
			buffer.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public String genBlockEntrance(int varSize)
	{
		String result = "MOVE	R0, -(SP)\n"
				+ "MOVE R7, R0\n"
				+ "MOVE R2, -(SP)\n"
				+ "ADD #-" + varSize + ", SP\n"
				+ genRegisterSave();
		return result;
	}
	
	public String genBlockExit(int varSize)
	{
		String result = "MOVE	R0, SP\n"
				+ "MOVE (SP)+, R0\n"
				+ "RTS\n"
				+ genRegisterLoad();
		return result;
	}
	
	public String genRegisterSave()
	{
		String result = "";
		for(int i=1; i<15; i++)
		{
			result += "MOVE R" + i + ", -(SP)\n";
		}
		return result;
	}
	
	public String genRegisterLoad()
	{
		String result = "";
		for(int i=14; i>0; i--)
		{
			result += "MOVE (SP)+, R" + i + "\n";
		}
		return result;
	}
	
	public String genVarAccess(SymbolTable table, String varName, Scope scope, int regId)
	{
		try {
			//int depthDiff = scope.getDepth() - table.getSymbol(varName, scope.getId()).depth;
			Symbol s = table.getSymbol(varName, scope.getId());
			return "MOVE (R0, " + s.disp + "), R"+regId;
		} catch (SymbolNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public String genScopeInit(Scope scope)
	{
		return "adi sp, sp, #-" + scope.getVarsSize() + "\n";
	}
	
	public String genReturnAdress()
	{
		return "stw bp, -(sp)\n"
				+ "ldw bp, sp\n";
	}
	
	public String genMainEnd()
	{
		return "ldw sp, bp\n"
				+ "ldw bp, (sp)+\n"
				+ "trp #EXIT_EXC\n"
				+ "jea @main_";
	}
	
	public String genVarAffect(SymbolTable table, int regId, String val)
	{
		return "stw R" + regId + ", " + val + "\n";
	}
	
	public String genLoadConst(int val)
	{
		return "ldw R0, #" + val + "\n";
	}
	
	public String genLoadAdr(int disp)
	{
		return "adi bp, r0, #-" + disp;
	}
	
	public String genLoadVal(int disp)
	{
		return "ldw r0, (bp)-" + disp;
	}
	
	public String genStack(int val)
	{
		return "stw r0, -(sp)\n";
	}
	
	public String genPrintVal()
	{
		return "jsr @itoa_\n"
				+ "adi sp, sp, #6\n";
	}
}
