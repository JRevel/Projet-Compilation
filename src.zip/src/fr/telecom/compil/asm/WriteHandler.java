package fr.telecom.compil.asm;

import fr.telecom.compil.SymbolTable;
import fr.telecom.compil.SymbolTable.Scope;
import fr.telecom.compil.SymbolTable.SymbolNotFoundException;
import fr.telecom.compil.SyntaxicTree;

public class WriteHandler implements TreeHandler
{
	public WriteHandler()
	{

	}

	public String genBefore(AsmGenerator gen, SyntaxicTree tree, Scope scope)
	{
		return "";
	}

	public String genAfter(AsmGenerator gen, SyntaxicTree tree, Scope scope)
	{
		String varName = tree.getChild().getChild().getLabel();
		try {
			return "adi sp, sp, #-8\n"   // r�serve place pour text sur pile (8 octets); 
			        // d�placement du d�but du tableau est -8

					//int value;
					+"adi sp, sp, #-2\n"   // r�serve place pour variable value;
			        // d�placement de value est -10

					//value = -23; 
					+"ldw r0, #-23\n"      // charge r0 avec -23 = C2(23) = FFE9
					+"stw r0, (bp)-10\n"   // sauve r0 � l'adresse bp-10       

					//itoa(value, text, 10); // appelle itoa avec i = value, p = text, b = 10

					+"ldw r0, #10\n"       // charge 10 (pour base d�cimale) dans r0
					+"stw r0, -(sp)\n"     // empile contenu de r0 (param�tre b)

					+"adi bp, r0, #-8\n"   // r0 = bp - 8 = adresse du tableau text
					+"stw r0, -(sp)\n"     // empile contenu de r0 (param�tre p)

					+ gen.genLoadAdr(scope.getSymbol(varName).disp)    // charge r0 avec value
					+"stw r0, -(sp)\n"     // empile contenu de r0 (param�tre i)

					+"jsr @itoa_\n"        // appelle fonction itoa d'adresse itoa_

					+"adi sp, sp, #6\n";
		} catch (SymbolNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
}
